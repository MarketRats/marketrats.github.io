/*
 * What the popup says about the facts page-scan.js read: sections of rows, each row with a state (ok / warn / bad /
 * info - always shown as a word and a colour), a short label, a value and an optional line or list. The limits follow
 * the site's own tools (src/app/api/irankiai/seo-patikra/analyze.ts: title 30-60, description 70-160, 300 words ...).
 * Pure functions (no DOM, no chrome.*): the popup uses them, node tests read them with vm. Texts in Lithuanian.
 */
(function (root) {
  "use strict";

  const SITE = "https://www.marketrats.lt/irankiai/";
  const WORD = { ok: "Gerai", warn: "Pataisyti", bad: "Problema", info: "Info" };

  const chars = text => Array.from(text).length;
  const cut = (text, max) => (chars(text) > max ? Array.from(text).slice(0, max - 1).join("") + "…" : text);
  const plural = (n, one, few, many) => {
    const ten = n % 10, hundred = n % 100;
    if (ten === 1 && hundred !== 11) return one;
    if (ten >= 2 && (hundred < 10 || hundred >= 20)) return few;
    return many;
  };
  const count = (n, one, few, many) => n + " " + plural(n, one, few, many);
  const withoutHash = url => {
    try { const parsed = new URL(url); parsed.hash = ""; return parsed.href; } catch (error) { return url; }
  };
  const row = (state, label, value, text, extra) => Object.assign({ state, label, value, text: text || null }, extra || {});

  function tagsSection(facts) {
    const rows = [];
    if (!facts.title) rows.push(row("bad", "Pavadinimas (title)", "Nėra", "Puslapis neturi <title> - Google pats parinks, ką rodyti paieškoje."));
    else {
      const n = chars(facts.title);
      const state = n < 30 || n > 60 || facts.titleCount > 1 ? "warn" : "ok";
      const note = n > 60 ? " Google gali nukirpti ties ~60 simbolių." : n < 30 ? " Trumpas: išnaudokite 30-60 simbolių." : "";
      const many = facts.titleCount > 1 ? " Puslapyje yra " + facts.titleCount + " <title> žymos." : "";
      rows.push(row(state, "Pavadinimas (title)", n + " simb.", "„" + facts.title + "“." + note + many));
    }
    if (!facts.description) rows.push(row("warn", "Aprašymas (description)", "Nėra", "Google rodys ištrauką iš teksto. Rekomenduojama 70-160 simbolių."));
    else {
      const n = chars(facts.description);
      const state = n < 70 || n > 160 || facts.descriptionCount > 1 ? "warn" : "ok";
      const note = n > 160 ? " Google gali nukirpti ties ~160 simbolių." : n < 70 ? " Trumpas: rekomenduojama 70-160 simbolių." : "";
      rows.push(row(state, "Aprašymas (description)", n + " simb.", "„" + cut(facts.description, 220) + "“." + note));
    }
    if (!facts.canonicals.length) rows.push(row("warn", "Kanoninis adresas", "Nėra", "Nurodykite pagrindinį šio puslapio adresą (rel=\"canonical\"), kad Google neindeksuotų jo kopijų."));
    else if (facts.canonicals.length > 1) rows.push(row("bad", "Kanoninis adresas", "Keli skirtingi", "Nurodyti " + facts.canonicals.length + " skirtingi adresai - Google gali juos visus ignoruoti.", { list: facts.canonicals }));
    else if (withoutHash(facts.canonicals[0]) === withoutHash(facts.url)) rows.push(row("ok", "Kanoninis adresas", "Rodo į save", facts.canonicals[0]));
    else rows.push(row("info", "Kanoninis adresas", "Rodo kitur", "Google indeksuos nurodytą adresą, ne šį: " + facts.canonicals[0]));
    const http = facts.http || { status: null, xRobotsTag: null, error: null };
    // The X-Robots-Tag header counts like meta robots (a "googlebot: noindex" form too); "unavailable_after" etc. are kept as info.
    const headerRules = http.xRobotsTag ? http.xRobotsTag.split(/,(?=\s*[a-z-]+\s*:)|;/i).map(part => part.trim()).filter(Boolean) : [];
    const rules = facts.robotsMeta.map(item => ({ source: item.name, content: item.content }))
      .concat(headerRules.map(part => ({ source: "X-Robots-Tag", content: part })));
    const noindex = rules.filter(item => /(^|[\s,:])(noindex|none)([\s,]|$)/i.test(item.content));
    const nofollow = rules.filter(item => /(^|[\s,:])nofollow([\s,]|$)/i.test(item.content));
    const shown = rules.map(item => item.source + ": " + item.content).join("; ");
    const header = http.xRobotsTag ? "" : http.error ? " X-Robots-Tag antraštės perskaityti nepavyko." : " X-Robots-Tag antraštės nėra.";
    if (noindex.length) rows.push(row("bad", "Indeksavimas (robots)", "noindex", "Google šio puslapio paieškoje nerodys (" + shown + ")." + header));
    else if (nofollow.length) rows.push(row("warn", "Indeksavimas (robots)", "nofollow", "Indeksuoti leidžiama, bet nuorodomis neina (" + shown + ")." + header));
    else rows.push(row("ok", "Indeksavimas (robots)", "Leidžiama", (shown ? shown + "." : "meta robots žymos nėra - indeksuoti leidžiama.") + header));
    // The HTTP status of the page itself.
    if (http.status === null) rows.push(row("info", "HTTP atsakymas", "Nežinomas", "Naršyklė nepateikė puslapio atsakymo kodo."));
    else if (http.status >= 200 && http.status < 300) rows.push(row("ok", "HTTP atsakymas", String(http.status), "Puslapis atsako tvarkingai."));
    else if (http.status >= 300 && http.status < 400) rows.push(row("warn", "HTTP atsakymas", String(http.status), "Puslapis peradresuoja - Google indeksuos galutinį adresą."));
    else rows.push(row("bad", "HTTP atsakymas", String(http.status), http.status === 404 || http.status === 410 ? "Puslapis atsako „nerasta“ - Google jo paieškoje nerodys, nors naršyklėje turinys matyti." : "Serveris atsako klaida - Google tokio puslapio paieškoje nerodys."));
    if (facts.lang) rows.push(row("ok", "Kalba (lang)", facts.lang));
    else rows.push(row("warn", "Kalba (lang)", "Nenurodyta", "Įrašykite puslapio kalbą: <html lang=\"lt\">."));
    return { id: "tags", title: "Pagrindinės žymos", tool: "seo-patikra", rows };
  }

  function contentSection(facts) {
    const rows = [];
    const c = facts.headingCounts;
    const firstH1 = facts.headings.find(item => item.level === 1);
    if (!c.h1) rows.push(row("bad", "H1 antraštė", "Nėra", "Pridėkite vieną H1, kuri aiškiai pasako, apie ką puslapis."));
    else if (c.h1 > 1) rows.push(row("warn", "H1 antraštė", c.h1 + " H1", "Viena aiški pagrindinė antraštė aiškesnė lankytojams ir paieškai.", { list: facts.headings.filter(item => item.level === 1).slice(0, 6).map(item => item.text || "(tuščia)") }));
    else rows.push(row("ok", "H1 antraštė", "1", firstH1 && firstH1.text ? "„" + firstH1.text + "“" : "(tuščia H1)"));
    if (!facts.headings.length) rows.push(row("warn", "Antraščių medis", "Nėra", "Puslapyje nėra H1-H3 antraščių."));
    else {
      const more = c.h1 + c.h2 + c.h3 > facts.headings.length ? ["... ir dar " + (c.h1 + c.h2 + c.h3 - facts.headings.length)] : [];
      rows.push(row("info", "Antraščių medis", "H1 " + c.h1 + " · H2 " + c.h2 + " · H3 " + c.h3, null, {
        outline: facts.headings.map(item => ({ level: item.level, text: item.text || "(tuščia)" })).concat(more.map(text => ({ level: 1, text }))),
      }));
    }
    const where = facts.textRoot === "main" ? "Skaičiuotas <main> tekstas." : facts.textRoot === "article" ? "Skaičiuotas <article> tekstas." : "Skaičiuotas puslapio tekstas be meniu ir poraštės.";
    // The homepage leads to other pages: little text there is normal, so it is not called a problem.
    const home = /^\/(index\.(html?|php))?$/i.test((facts.path || "/").split("?")[0]);
    if (facts.words >= 300) rows.push(row("ok", "Teksto kiekis", "~" + facts.words + " žodž.", where));
    else if (home) rows.push(row("info", "Teksto kiekis", "~" + facts.words + " žodž.", "Tituliniame puslapyje nedaug teksto - įprasta. Išsamaus teksto labiausiai reikia paslaugų, prekių ir straipsnių puslapiams. " + where));
    else rows.push(row("warn", "Teksto kiekis", "~" + facts.words + " žodž.", "Mažiau nei 300 žodžių - puslapis gali būti per plonas paieškai. " + where));
    return { id: "content", title: "Antraštės ir tekstas", tool: "seo-patikra", rows };
  }

  function mediaSection(facts) {
    const rows = [];
    const img = facts.images;
    const empty = img.emptyAlt ? " Tuščią alt turi " + img.emptyAlt + " (tinka dekoratyviems)." : "";
    if (!img.total) rows.push(row("info", "Paveikslėlių alt", "Nerasta", "Puslapyje nėra img paveikslėlių (jie gali būti CSS fone arba įkeliami vėliau)."));
    else if (!img.noAlt) rows.push(row("ok", "Paveikslėlių alt", "Visi " + img.total, "Alt atributą turi visi paveikslėliai." + empty));
    else {
      const bad = img.noAlt >= 5 && img.noAlt / img.total >= 0.5;
      rows.push(row(bad ? "bad" : "warn", "Paveikslėlių alt", img.noAlt + " iš " + img.total, "Be alt atributo - aprašykite, kas paveikslėlyje." + empty, { list: img.examples }));
    }
    const l = facts.links;
    const nofollow = l.nofollow ? " Su nofollow: " + l.nofollow + "." : "";
    rows.push(row("info", "Nuorodos", l.internal + " vid. · " + l.external + " išor.", "Į tą pačią svetainę: " + l.internal + ", į kitas: " + l.external + (l.other ? ", el. paštas ir telefonas: " + l.other : "") + "." + nofollow));
    return { id: "media", title: "Paveikslėliai ir nuorodos", tool: "seo-patikra", rows };
  }

  function botsSection(facts) {
    const R = root.MRRobots;
    const rows = [];
    const fetched = facts.robots;
    const robots = R.readRobots(fetched);
    if (robots.state === "found") {
      if (fetched.html) rows.push(row("warn", "robots.txt", "HTML puslapis", "Adresu /robots.txt grąžinamas HTML puslapis, ne taisyklės - robotai tai skaito kaip „taisyklių nėra“."));
      else rows.push(row("ok", "robots.txt", "Rastas", count(robots.parsed.lines, "eilutė", "eilutės", "eilučių") + ", " + count(robots.parsed.groups.length, "grupė", "grupės", "grupių") + (fetched.truncated ? ". Failas didesnis nei 500 KB - skaityta pradžia." : ".")));
    } else if (robots.state === "missing") rows.push(row("info", "robots.txt", "Nėra (HTTP " + fetched.status + ")", "Be robots.txt robotams leidžiama skaityti viską."));
    else if (robots.state === "unreachable") rows.push(row("bad", "robots.txt", "HTTP " + fetched.status, "Serveris atsako klaida - pagal RFC 9309 tada robotams uždrausta viskas."));
    else rows.push(row("info", "robots.txt", "Neperskaitytas", fetched && fetched.error === "timeout" ? "Svetainė neatsakė per 8 s." : "Naršyklė neleido jo perskaityti iš šio puslapio. Patikrinkite Market Rats įrankyje."));
    if (robots.state !== "unknown") {
      for (const bot of R.BOTS) {
        const verdict = R.verdictFor(robots, bot.token, facts.path);
        const blocked = verdict.status === "blocked";
        const state = blocked ? (bot.group === "training" && verdict.via !== "unreachable" ? "info" : "bad") : "ok";
        const why = verdict.via === "unreachable" ? " robots.txt nepasiekiamas." : verdict.rule ? " " + verdict.rule.text + " (" + verdict.rule.line + " eil., grupė " + (verdict.via === "own" ? bot.token : "*") + ")." : "";
        rows.push(row(state, bot.token, blocked ? "Uždrausta" : "Leidžiama", bot.purpose + "." + why, { bot: true }));
      }
    }
    const tail = robots.state === "found" ? " Robotui be jam taikomos taisyklės leidžiama." : "";
    return { id: "bots", title: "AI robotai ir robots.txt", tool: "ai-robotu-patikra", rows, note: "Tikrinta šiam puslapiui: " + cut(facts.path, 80) + "." + tail };
  }

  const HREFLANG = /^(x-default|[a-z]{2,3}(-[a-z]{4})?(-([a-z]{2}|\d{3}))?)$/i;

  function hreflangSection(facts) {
    const rows = [];
    const items = facts.hreflang;
    if (!items.length) rows.push(row("info", "Kalbų versijos", "Nėra", "Hreflang žymos reikalingos tik daugiakalbėms svetainėms."));
    else {
      const wrong = items.filter(item => !HREFLANG.test(item.lang));
      const here = [withoutHash(facts.url)].concat(facts.canonicals.map(withoutHash));
      const self = items.some(item => item.href && here.includes(withoutHash(item.href)));
      const xDefault = items.some(item => item.lang.toLowerCase() === "x-default");
      const notes = [];
      if (wrong.length) notes.push("Neteisingi kodai: " + wrong.map(item => item.lang).join(", ") + ".");
      if (!self) notes.push("Nėra nuorodos į šį puslapį - kiekviena versija turi nurodyti ir save.");
      if (!xDefault) notes.push("Nėra x-default (nebūtina).");
      rows.push(row(wrong.length || !self ? "warn" : "ok", "Kalbų versijos", count(items.length, "žyma", "žymos", "žymų"), notes.join(" ") || "Kodai teisingi, yra nuoroda į save.", {
        list: items.map(item => item.lang + " - " + (item.href || "(be adreso)")),
      }));
      rows.push(row("info", "Abipusės nuorodos", "Netikrinta", "Ar kitos versijos rodo atgal, plėtinys nemato - tai parodo hreflang patikra."));
    }
    return { id: "hreflang", title: "Kalbų versijos (hreflang)", tool: "hreflang-patikra", rows };
  }

  function socialSection(facts) {
    const og = facts.og;
    const rows = [];
    rows.push(og.title ? row("ok", "og:title", chars(og.title) + " simb.", "„" + cut(og.title, 140) + "“") : row("warn", "og:title", "Nėra", facts.title ? "Programos greičiausiai paims <title>." : "Pasidalijus nuoroda pavadinimo nebus."));
    rows.push(og.description ? row("ok", "og:description", chars(og.description) + " simb.", "„" + cut(og.description, 160) + "“") : row("warn", "og:description", "Nėra", "Programos pačios parinks tekstą arba jo nerodys."));
    if (!og.image) rows.push(row("warn", "og:image", "Nėra", "Nuoroda bus be paveikslėlio arba su atsitiktiniu. Rekomenduojama 1200x630 px."));
    else if (!/^https?:\/\//i.test(og.image)) rows.push(row("warn", "og:image", "Ne pilnas adresas", "Nurodykite pilną adresą su https://: " + cut(og.image, 120)));
    else rows.push(row("ok", "og:image", "Yra", cut(og.image, 160)));
    rows.push(og.twitterCard ? row("info", "twitter:card", og.twitterCard) : row("info", "twitter:card", "Nėra", "X naudos Open Graph žymas."));
    return { id: "social", title: "Socialiniai tinklai", tool: "socialiniu-tinklu-perziura", rows };
  }

  function schemaSection(facts) {
    const rows = [];
    const ld = facts.jsonld;
    if (!ld.blocks && !facts.microdata.length) rows.push(row("warn", "Struktūriniai duomenys", "Nėra", "Struktūriniai duomenys (JSON-LD) padeda Google ir AI suprasti, kas yra puslapyje."));
    else if (ld.blocks && ld.errors) rows.push(row("bad", "JSON-LD", ld.errors + " iš " + ld.blocks + " su klaidomis", "Google neskaitys blokų su JSON klaidomis." + (ld.types.length ? " Teisinguose: " + ld.types.join(", ") + "." : "")));
    else if (ld.blocks) rows.push(row("ok", "JSON-LD", count(ld.blocks, "blokas", "blokai", "blokų"), ld.types.length ? "Tipai: " + ld.types.join(", ") + "." : "Tipai nenurodyti (@type)."));
    if (facts.microdata.length) rows.push(row("info", "Microdata", count(facts.microdata.length, "tipas", "tipai", "tipų"), facts.microdata.join(", ")));
    return { id: "schema", title: "Struktūriniai duomenys", tool: "schema-generatorius", rows };
  }

  /** Every section of the popup, in its order, and the totals for the summary line. */
  function analyze(facts) {
    const sections = [tagsSection(facts), contentSection(facts), mediaSection(facts), botsSection(facts), hreflangSection(facts), socialSection(facts), schemaSection(facts)];
    const totals = { bad: 0, warn: 0, ok: 0, info: 0 };
    for (const section of sections) {
      // The Market Rats tool opens with this page's address filled in and runs at once.
      section.url = SITE + section.tool + "?url=" + encodeURIComponent(withoutHash(facts.url));
      section.counts = { bad: 0, warn: 0, ok: 0, info: 0 };
      for (const item of section.rows) { section.counts[item.state]++; totals[item.state]++; }
    }
    return { sections, totals, auditUrl: SITE + "svetaines-auditas?url=" + encodeURIComponent(facts.origin || facts.url) };
  }

  /** The popup's findings as plain text (for an e-mail or a task): problems first in each section, one line per row. */
  function reportText(facts, result) {
    const RANK = { bad: 0, warn: 1, info: 2, ok: 3 };
    const t = result.totals;
    const lines = [
      "Market Rats SEO - " + withoutHash(facts.url),
      "Problemos: " + t.bad + " · Pataisyti: " + t.warn + " · Gerai: " + t.ok + " · Info: " + t.info,
    ];
    for (const section of result.sections) {
      lines.push("", section.title.toLocaleUpperCase("lt-LT"));
      const rows = section.rows.slice().sort((a, b) => RANK[a.state] - RANK[b.state]);
      for (const item of rows) lines.push("[" + WORD[item.state] + "] " + item.label + ": " + item.value + (item.text ? " - " + item.text : ""));
      if (section.note) lines.push(section.note);
    }
    lines.push("", "Patikrinta " + new Date().toLocaleString("lt-LT") + " Market Rats SEO plėtiniu.");
    return lines.join("\n");
  }

  root.MRAnalyze = { analyze, reportText, WORD, SITE, cut, count };
})(typeof self !== "undefined" ? self : globalThis);
