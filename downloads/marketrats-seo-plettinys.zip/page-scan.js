/*
 * Reads the open page. The popup hands this function to chrome.scripting.executeScript, which runs a COPY of its
 * source in the tab (isolated world: the page's own scripts cannot change what it sees), so it must not use anything
 * from outside its own body. It only reads the DOM and asks the page's own origin for /robots.txt and the page's own
 * headers (one HEAD request to the same address); it sends nothing anywhere else. Every text is cut to a short length, so a huge or hostile page cannot flood the popup.
 */
// eslint-disable-next-line no-unused-vars
async function mrScanPage() {
  "use strict";
  const clean = value => String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  const cut = (value, max) => (value.length > max ? value.slice(0, max - 1) + "…" : value);
  const absolute = href => {
    try { return new URL(href, document.baseURI).href; } catch (error) { return null; }
  };
  const relOf = element => (element.getAttribute("rel") || "").toLowerCase().split(/\s+/).filter(Boolean);
  const metas = Array.from(document.getElementsByTagName("meta"));
  const metaAll = key => metas.filter(meta => (meta.getAttribute("name") || "").toLowerCase() === key || (meta.getAttribute("property") || "").toLowerCase() === key).map(meta => clean(meta.getAttribute("content")));
  const meta = key => { const found = metaAll(key); return found.length ? cut(found[0], 400) : null; };

  // Title: what the tab shows (scripts may change it); the count of HTML <title> elements (not SVG titles).
  const titleElements = Array.from(document.getElementsByTagName("title")).filter(element => element.namespaceURI === "http://www.w3.org/1999/xhtml" && !element.closest("svg"));
  const title = titleElements.length ? cut(clean(document.title), 300) : null;
  const descriptions = metaAll("description");
  const canonicals = Array.from(document.querySelectorAll("link[rel]")).filter(link => relOf(link).includes("canonical")).map(link => absolute(link.getAttribute("href") || "")).filter(Boolean);
  const robotsMeta = metas
    .filter(item => /^(robots|googlebot)$/i.test(item.getAttribute("name") || ""))
    .map(item => ({ name: (item.getAttribute("name") || "").toLowerCase(), content: cut(clean(item.getAttribute("content")), 200) }))
    .slice(0, 6);

  // Headings H1-H3 in page order (the outline), at most 80; every H1 counted.
  const headings = Array.from(document.querySelectorAll("h1, h2, h3")).slice(0, 80).map(element => ({
    level: Number(element.tagName.slice(1)),
    text: cut(clean(element.innerText || element.textContent), 140),
  }));
  const allHeadings = { h1: document.getElementsByTagName("h1").length, h2: document.getElementsByTagName("h2").length, h3: document.getElementsByTagName("h3").length };

  // Words of the main text: <main> (or role=main), else the first <article>, else the page without its menus,
  // header, footer and side blocks. innerText = what is rendered (no scripts, styles or hidden blocks).
  const countWords = text => (String(text).match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu) || []).length;
  const mains = document.querySelectorAll("main, [role='main']");
  let textRoot = "page";
  let words = 0;
  if (mains.length) {
    textRoot = "main";
    words = Array.from(mains).filter(element => !element.parentElement || !element.parentElement.closest("main, [role='main']")).reduce((sum, element) => sum + countWords(element.innerText || ""), 0);
  } else if (document.querySelector("article")) {
    textRoot = "article";
    words = countWords(document.querySelector("article").innerText || "");
  } else if (document.body) {
    words = countWords(document.body.innerText || "");
    const frame = Array.from(document.body.querySelectorAll("nav, header, footer, aside")).filter(element => !element.parentElement || !element.parentElement.closest("nav, header, footer, aside"));
    for (const element of frame) words -= countWords(element.innerText || "");
    words = Math.max(0, words);
  }

  // Images: without an alt attribute at all (empty alt is right for decoration, counted apart).
  const images = Array.from(document.images);
  const noAlt = images.filter(image => !image.hasAttribute("alt"));
  const imageInfo = {
    total: images.length,
    noAlt: noAlt.length,
    emptyAlt: images.filter(image => image.getAttribute("alt") === "").length,
    examples: noAlt.slice(0, 5).map(image => cut(image.currentSrc || image.src || image.getAttribute("data-src") || "(be adreso)", 160)),
  };

  // Links: same site (the host, or the host with / without www.) or another site; mailto / tel apart.
  const bare = name => name.toLowerCase().replace(/^www\./, "");
  const here = bare(location.hostname);
  const links = { total: 0, internal: 0, external: 0, other: 0, nofollow: 0 };
  for (const anchor of Array.from(document.querySelectorAll("a[href]")).slice(0, 5000)) {
    const href = (anchor.getAttribute("href") || "").trim();
    if (!href || href.startsWith("#") || /^javascript:/i.test(href)) continue;
    links.total++;
    const url = absolute(href);
    if (!url) continue;
    const parsed = new URL(url);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") { links.other++; continue; }
    if (bare(parsed.hostname) === here) links.internal++;
    else links.external++;
    if (relOf(anchor).includes("nofollow")) links.nofollow++;
  }

  // Language versions (hreflang) as <link rel="alternate" hreflang>.
  const hreflang = Array.from(document.querySelectorAll("link[hreflang]"))
    .filter(link => relOf(link).includes("alternate"))
    .slice(0, 60)
    .map(link => ({ lang: cut(clean(link.getAttribute("hreflang")), 20), href: absolute(link.getAttribute("href") || "") }));

  const og = {
    title: meta("og:title"), description: meta("og:description"), image: meta("og:image"), url: meta("og:url"), type: meta("og:type"), siteName: meta("og:site_name"),
    twitterCard: meta("twitter:card"), twitterImage: meta("twitter:image"),
  };

  // JSON-LD: blocks, the ones that do not parse, every @type inside (nested and @graph too); microdata itemtypes.
  const types = [];
  const collect = (value, depth) => {
    if (depth > 40 || types.length > 200) return;
    if (Array.isArray(value)) { value.forEach(item => collect(item, depth + 1)); return; }
    if (!value || typeof value !== "object") return;
    const type = value["@type"];
    if (typeof type === "string") types.push(type);
    else if (Array.isArray(type)) type.forEach(item => typeof item === "string" && types.push(item));
    Object.keys(value).forEach(key => collect(value[key], depth + 1));
  };
  const blocks = Array.from(document.querySelectorAll("script[type]")).filter(script => /^application\/ld\+json\b/i.test((script.getAttribute("type") || "").trim()));
  let jsonErrors = 0;
  for (const block of blocks.slice(0, 50)) {
    const text = (block.textContent || "").trim().replace(/^<!--/, "").replace(/-->$/, "").replace(/^\/\/\s*<!\[CDATA\[/, "").replace(/\/\/\s*\]\]>$/, "").trim();
    if (!text || text.length > 1000000) { jsonErrors++; continue; }
    try { collect(JSON.parse(text), 0); } catch (error) { jsonErrors++; }
  }
  const itemtypes = Array.from(document.querySelectorAll("[itemscope][itemtype]")).slice(0, 200)
    .map(element => (element.getAttribute("itemtype") || "").trim().split(/\s+/)[0].replace(/\/+$/, "").split("/").pop())
    .filter(Boolean);

  // robots.txt of this origin, as a crawler reads it: at most 500 KiB, up to 8 s, without cookies.
  const robots = { url: location.origin + "/robots.txt", status: null, text: null, html: false, truncated: false, error: null };
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const response = await fetch(robots.url, { credentials: "omit", cache: "no-cache", redirect: "follow", signal: controller.signal });
    robots.status = response.status;
    if (response.ok && response.body) {
      const reader = response.body.getReader();
      const chunks = [];
      let size = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
        size += value.length;
        if (size >= 512000) { robots.truncated = size > 512000; reader.cancel().catch(() => {}); break; }
      }
      const bytes = new Uint8Array(Math.min(size, 512000));
      let offset = 0;
      for (const chunk of chunks) {
        if (offset >= bytes.length) break;
        const part = chunk.subarray(0, bytes.length - offset);
        bytes.set(part, offset);
        offset += part.length;
      }
      robots.text = new TextDecoder("utf-8").decode(bytes);
      robots.html = /html/i.test(response.headers.get("content-type") || "") && /<(!doctype|html|head|body)\b/i.test(robots.text.slice(0, 2000));
    }
    clearTimeout(timer);
  } catch (error) {
    robots.status = null;
    robots.error = error && error.name === "AbortError" ? "timeout" : "network";
  }

  // The page's HTTP answer: the status Chrome got when it loaded the page (Navigation Timing, Chrome 109+, no request),
  // and one HEAD request to the same address - the same origin, without cookies, as a crawler asks - for the
  // X-Robots-Tag header (and the status on older Chrome). A server that refuses HEAD (405 / 501) gets a GET whose body
  // is not read.
  const http = { status: null, xRobotsTag: null, error: null };
  try {
    const nav = performance.getEntriesByType("navigation")[0];
    if (nav && typeof nav.responseStatus === "number" && nav.responseStatus > 0) http.status = nav.responseStatus;
  } catch (error) { /* older Chrome: the request below gives the status */ }
  try {
    const ask = async method => {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 6000);
      try {
        const response = await fetch(location.href, { method, credentials: "omit", cache: "no-store", redirect: "manual", signal: controller.signal });
        if (method === "GET" && response.body) response.body.cancel().catch(() => {});
        return response;
      } finally {
        clearTimeout(timer);
      }
    };
    let response = await ask("HEAD");
    if (response.status === 405 || response.status === 501) response = await ask("GET");
    // redirect: "manual" gives an opaque answer for a redirect: no headers to read then.
    if (response.type !== "opaqueredirect") {
      if (http.status === null) http.status = response.status;
      const tag = response.headers.get("x-robots-tag");
      http.xRobotsTag = tag ? cut(clean(tag), 300) : null;
    }
  } catch (error) {
    http.error = error && error.name === "AbortError" ? "timeout" : "network";
  }

  return {
    url: location.href,
    http,
    origin: location.origin,
    host: location.hostname,
    path: location.pathname + location.search,
    lang: clean(document.documentElement.getAttribute("lang")) || null,
    title,
    titleCount: titleElements.length,
    description: descriptions.length ? cut(descriptions[0], 400) : null,
    descriptionCount: descriptions.length,
    canonicals: Array.from(new Set(canonicals)).slice(0, 5),
    canonicalCount: canonicals.length,
    robotsMeta,
    headings,
    headingCounts: allHeadings,
    words,
    textRoot,
    images: imageInfo,
    links,
    hreflang,
    og,
    jsonld: { blocks: blocks.length, errors: jsonErrors, types: Array.from(new Set(types)).slice(0, 30) },
    microdata: Array.from(new Set(itemtypes)).slice(0, 20),
    robots,
  };
}
