/*
 * The popup: reads the active tab with page-scan.js (chrome.scripting, allowed by activeTab only after the visitor
 * clicks the icon), turns the facts into sections with analyze.js and shows them. Everything from the page is put in
 * as text (textContent), never as HTML. No requests from here: the only ones are the page's own /robots.txt and one
 * HEAD request for the page's headers, made by page-scan.js inside the tab. "Kopijuoti ataskaitą" copies the findings
 * as text; the links to the Market Rats tools carry the page's address (?url=), so the tool opens filled in.
 */
(function () {
  "use strict";
  const out = document.getElementById("out");
  const hostLine = document.getElementById("host");
  const again = document.getElementById("again");
  const { analyze, reportText, WORD, cut } = self.MRAnalyze;

  const plural = (n, one, few, many) => {
    const ten = n % 10, hundred = n % 100;
    if (ten === 1 && hundred !== 11) return one;
    if (ten >= 2 && (hundred < 10 || hundred >= 20)) return few;
    return many;
  };
  const COUNT_WORD = {
    bad: n => plural(n, "problema", "problemos", "problemų"),
    warn: () => "pataisyti",
    ok: () => "gerai",
    info: () => "info",
  };
  const ORDER = ["bad", "warn", "ok", "info"];

  /** A small element builder: attributes as given, children as nodes or text (text nodes - never parsed as HTML). */
  function el(tag, attrs, ...children) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs || {})) {
      if (value === null || value === undefined || value === false) continue;
      if (key === "className") node.className = value;
      else if (key === "dataset") Object.assign(node.dataset, value);
      else node.setAttribute(key, value === true ? "" : String(value));
    }
    for (const child of children.flat()) {
      if (child === null || child === undefined || child === false) continue;
      node.append(typeof child === "string" ? document.createTextNode(child) : child);
    }
    return node;
  }

  const show = (...nodes) => out.replaceChildren(...nodes.flat());
  const pill = state => el("span", { className: "mr-pill", dataset: { state } }, WORD[state]);

  function note(title, text) {
    show(el("div", { className: "mr-note", role: "status" }, el("p", { className: "mr-note-title" }, title), el("p", null, text)));
  }

  function counts(values) {
    return el("span", { className: "mr-counts" }, ORDER.filter(state => values[state]).map(state => el("span", { dataset: { state } }, values[state] + " " + COUNT_WORD[state](values[state]))));
  }

  function rowOf(item) {
    const node = el("li", { className: "mr-row", dataset: { state: item.state } },
      pill(item.state),
      el("span", { className: "mr-label" }, item.label),
      el("span", { className: "mr-value" }, item.value));
    if (item.text) node.append(el("p", { className: "mr-text" }, item.text));
    if (item.list && item.list.length) node.append(el("ul", { className: "mr-list" }, item.list.map(line => el("li", null, line))));
    if (item.outline && item.outline.length) {
      node.append(el("ol", { className: "mr-outline" }, item.outline.map(heading => el("li", { dataset: { level: String(heading.level) } }, el("b", null, "H" + heading.level), " ", heading.text))));
    }
    return node;
  }

  function sectionOf(section) {
    const issues = section.counts.bad + section.counts.warn;
    // Sections with something to fix start open; the rest fold to their heading line (as on the site).
    return el("details", { className: "mr-sec", open: issues > 0 },
      el("summary", null, el("span", { className: "mr-sec-title" }, section.title), counts(section.counts)),
      el("ul", { className: "mr-rows" }, section.rows.map(rowOf)),
      section.note ? el("p", { className: "mr-sec-note" }, section.note) : null,
      el("a", { className: "mr-more", href: section.url, target: "_blank", rel: "noopener" }, "Plačiau Market Rats įrankyje", el("span", { "aria-hidden": "true" }, " ↗")));
  }

  /** Copies the report as text; the old way (a hidden text field) when the clipboard API is refused. */
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (error) {
      const area = el("textarea", { readonly: true, style: "position:fixed;top:0;left:0;opacity:0;" });
      area.value = text;
      document.body.append(area);
      area.select();
      const ok = document.execCommand("copy");
      area.remove();
      return ok;
    }
  }

  function render(facts) {
    const result = analyze(facts);
    const { sections, totals } = result;
    const copy = el("button", { className: "mr-act", type: "button" }, "Kopijuoti ataskaitą");
    copy.addEventListener("click", async () => {
      const ok = await copyText(reportText(facts, result));
      copy.textContent = ok ? "Nukopijuota" : "Nepavyko nukopijuoti";
      setTimeout(() => { copy.textContent = "Kopijuoti ataskaitą"; }, 2000);
    });
    show(
      el("div", { className: "mr-sum" },
        el("p", { className: "mr-sum-url", title: facts.url }, cut(facts.host + facts.path, 70)),
        counts(totals),
        el("div", { className: "mr-acts" },
          copy,
          el("a", { className: "mr-act", href: result.auditUrl, target: "_blank", rel: "noopener" }, "Patikrinti visą svetainę", el("span", { "aria-hidden": "true" }, " ↗")))),
      sections.map(sectionOf));
  }

  async function run() {
    again.hidden = true;
    show(el("p", { className: "mr-loading", role: "status" }, "Skaitomas puslapis..."));
    let tab = null;
    try {
      [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    } catch (error) {
      tab = null;
    }
    const url = (tab && tab.url) || "";
    let host = "";
    try { host = url ? new URL(url).hostname : ""; } catch (error) { host = ""; }
    hostLine.textContent = host || "Šis puslapis";
    if (!tab || !/^https?:\/\//i.test(url)) {
      note("Šio puslapio plėtinys neskaito", "Plėtinys veikia svetainėse, kurių adresas prasideda http:// arba https://. Chrome vidiniai puslapiai (chrome://), failai ir plėtinių parduotuvė netikrinami. Atidarykite svetainę ir paspauskite plėtinio ženklą dar kartą.");
      return;
    }
    try {
      const results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: mrScanPage });
      const facts = results && results[0] && results[0].result;
      if (!facts) throw new Error("puslapis negrąžino duomenų");
      render(facts);
    } catch (error) {
      note("Chrome neleido perskaityti šio puslapio", "Kai kurių puslapių (pvz., Chrome Web Store, PDF peržiūros ar dar neįkelto puslapio) plėtiniai skaityti negali. Perkraukite puslapį ir pabandykite dar kartą." + (error && error.message ? " (" + error.message + ")" : ""));
    }
    again.hidden = false;
  }

  again.addEventListener("click", run);
  run();
})();
