/*
 * robots.txt read the way RFC 9309 (and Google's open-source parser) reads it. A plain-JavaScript port of the pure
 * functions in the site's src/app/api/irankiai/ai-robotu-patikra/robots-txt.ts (productToken, normalizePattern,
 * parseRobots, patternMatches, rulesFor, decide) - keep the two alike when one of them changes:
 * - a group is one or more "User-agent" lines followed by rules; a User-agent line after a rule starts a new group;
 * - a crawler takes the groups whose User-agent product token equals its own (case-insensitive), all of them merged;
 *   only when there is none does it take the "*" groups; with neither, everything is allowed;
 * - Allow / Disallow paths match from the start of the path (with the query), "*" is any characters, a final "$" is
 *   the end of the path; the longest matching path wins and Allow wins a tie; an empty Disallow allows everything.
 * Plus the verdict for one crawler as the site's AI robots tool gives it (2xx = rules, 4xx = everything allowed,
 * 429 / 5xx / no answer = everything disallowed). No DOM, no requests: the popup uses it, node tests read it with vm.
 */
(function (root) {
  "use strict";

  const KEY_ALIASES = {
    "user-agent": "user-agent", useragent: "user-agent", "user agent": "user-agent",
    allow: "allow",
    disallow: "disallow", dissallow: "disallow", dissalow: "disallow", disalow: "disallow", diasllow: "disallow", disallaw: "disallow",
    sitemap: "sitemap", "site-map": "sitemap",
    "content-signal": "content-signal",
  };

  /** "Googlebot/2.1 (+http://...)" -> "googlebot"; "*" -> "*". */
  function productToken(value) {
    const trimmed = String(value).trim();
    if (trimmed.startsWith("*")) return "*";
    const match = /^[A-Za-z0-9_-]+/.exec(trimmed);
    return (match ? match[0] : "").toLowerCase();
  }

  /** Non-ASCII characters percent-encoded (UTF-8) and %xx in upper case, as in a URL path. */
  function normalizePattern(pattern) {
    let out = "";
    for (const char of pattern) out += char.charCodeAt(0) > 0x7e || char === " " ? encodeURIComponent(char) : char;
    return out.replace(/%[0-9a-f]{2}/gi, code => code.toUpperCase());
  }

  function parseRobots(text) {
    const groups = [];
    const sitemaps = [];
    const contentSignals = [];
    let current = null;
    const lines = String(text).replace(/^﻿/, "").split(/\r\n|\r|\n/);
    lines.forEach((raw, index) => {
      const line = index + 1;
      const content = raw.replace(/#.*$/, "").trim();
      // Split at the first colon (a lazy regex here would be quadratic on long space runs without a colon).
      const colon = content.indexOf(":");
      if (colon <= 0) return;
      const name = content.slice(0, colon).trim();
      if (!/^[A-Za-z][A-Za-z -]*$/.test(name)) return;
      const key = KEY_ALIASES[name.toLowerCase().replace(/\s+/g, " ")];
      const value = content.slice(colon + 1).trim();
      if (key === "user-agent") {
        const token = productToken(value);
        if (!token) return;
        if (current && !current.closed) current.agents.push(token);
        else {
          current = { agents: [token], rules: [], line, closed: false };
          groups.push(current);
        }
      } else if (key === "allow" || key === "disallow") {
        if (!current) return; // rules before any User-agent line belong to no group
        current.closed = true;
        if (!value) return; // "Disallow:" with no path allows everything; an empty Allow says nothing
        current.rules.push({ allow: key === "allow", pattern: normalizePattern(value), line, text: (key === "allow" ? "Allow: " : "Disallow: ") + value });
      } else if (key === "sitemap") {
        if (value) sitemaps.push(value);
      } else if (key === "content-signal") {
        contentSignals.push({ line, text: content });
      }
    });
    return { groups, sitemaps, contentSignals, lines: lines.length };
  }

  /** Does a robots.txt path pattern match this path (path + query)? Linear in practice: the set of reachable positions. */
  function patternMatches(path, pattern) {
    const n = path.length;
    let positions = [0];
    for (let j = 0; j < pattern.length; j++) {
      const char = pattern[j];
      if (char === "$" && j === pattern.length - 1) return positions[positions.length - 1] === n;
      if (char === "*") {
        const from = positions[0];
        positions = [];
        for (let p = from; p <= n; p++) positions.push(p);
        continue;
      }
      const next = [];
      for (const p of positions) if (p < n && path[p] === char) next.push(p + 1);
      if (!next.length) return false;
      positions = next;
    }
    return true;
  }

  /** The rules this crawler follows: its own groups merged, else the "*" groups merged, else none. */
  function rulesFor(parsed, token) {
    const own = parsed.groups.filter(group => group.agents.includes(token.toLowerCase()));
    if (own.length) return { kind: "specific", rules: own.flatMap(group => group.rules), groupLines: own.map(group => group.line) };
    const global = parsed.groups.filter(group => group.agents.includes("*"));
    if (global.length) return { kind: "global", rules: global.flatMap(group => group.rules), groupLines: global.map(group => group.line) };
    return { kind: "none", rules: [], groupLines: [] };
  }

  /** The longest matching rule decides; Allow wins a tie; no match = allowed. /robots.txt itself is always allowed. */
  function decide(rules, path) {
    if (path === "/robots.txt") return { allowed: true, rule: null };
    let best = null;
    for (const rule of rules) {
      if (!patternMatches(path, rule.pattern)) continue;
      if (!best || rule.pattern.length > best.pattern.length || (rule.pattern.length === best.pattern.length && rule.allow && !best.allow)) best = rule;
    }
    return { allowed: best ? best.allow : true, rule: best };
  }

  /**
   * The crawlers the popup shows (tokens and purposes as in the site's AI robots tool, src/al/pages/irankiai/ai-robotai/types.ts).
   * "answers" = search and answer bots (blocking them hides the site from answers); "training" = model training (a choice).
   */
  const BOTS = [
    { token: "Googlebot", vendor: "Google", purpose: "Google paieška, AI apžvalgos ir AI režimas", group: "answers" },
    { token: "OAI-SearchBot", vendor: "OpenAI", purpose: "ChatGPT paieška", group: "answers" },
    { token: "ChatGPT-User", vendor: "OpenAI", purpose: "ChatGPT atidaro puslapį naudotojo prašymu", group: "answers" },
    { token: "PerplexityBot", vendor: "Perplexity", purpose: "Perplexity paieškos indeksas", group: "answers" },
    { token: "GPTBot", vendor: "OpenAI", purpose: "OpenAI modelių mokymas", group: "training" },
    { token: "ClaudeBot", vendor: "Anthropic", purpose: "Anthropic modelių mokymas", group: "training" },
    { token: "Google-Extended", vendor: "Google", purpose: "Gemini mokymas; AI apžvalgoms įtakos neturi", group: "training" },
  ];

  /**
   * How a fetched robots.txt reads: { state: "found" | "missing" | "unreachable" | "unknown", parsed }.
   * status null + error = no answer (network, timeout, the page's rules) - "unknown", the popup cannot tell.
   */
  function readRobots(fetched) {
    if (!fetched || fetched.status === null || fetched.status === undefined) return { state: "unknown", parsed: null };
    if (fetched.status >= 200 && fetched.status < 300) return { state: "found", parsed: parseRobots(fetched.text || "") };
    // 429 and 5xx: RFC 9309 says to assume a complete disallow (Google treats 429 the same way).
    if (fetched.status === 429 || fetched.status >= 500) return { state: "unreachable", parsed: null };
    // 4xx (including 401 / 403): "unavailable" - a crawler may access everything.
    return { state: "missing", parsed: null };
  }

  /** One crawler on one path: { status: "allowed" | "default" | "blocked" | "unknown", via, rule }. */
  function verdictFor(robots, token, path) {
    if (robots.state === "unknown") return { status: "unknown", via: "unknown", rule: null };
    if (robots.state === "unreachable") return { status: "blocked", via: "unreachable", rule: null };
    if (!robots.parsed) return { status: "default", via: "none", rule: null };
    const rules = rulesFor(robots.parsed, token);
    if (rules.kind === "none") return { status: "default", via: "none", rule: null };
    const via = rules.kind === "specific" ? "own" : "all";
    const decision = decide(rules.rules, path);
    if (!decision.rule) return { status: "default", via, rule: null };
    return { status: decision.allowed ? "allowed" : "blocked", via, rule: { line: decision.rule.line, text: decision.rule.text } };
  }

  root.MRRobots = { productToken, normalizePattern, parseRobots, patternMatches, rulesFor, decide, readRobots, verdictFor, BOTS };
})(typeof self !== "undefined" ? self : globalThis);
